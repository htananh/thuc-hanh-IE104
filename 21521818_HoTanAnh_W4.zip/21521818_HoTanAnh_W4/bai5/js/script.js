let pass= document.getElementById("password");
pass.addEventListener("click", function(){
    confirm(
        "bạn muốn hiện mật khẩu"
    )
})